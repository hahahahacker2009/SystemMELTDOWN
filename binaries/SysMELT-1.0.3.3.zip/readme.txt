8:21 PM GMT+7, 13/8/2021
(C) Copyright 2021, FreeGenerator Inc. All rights reserved.

This is the binary of the malware SystemMELTDOWN. But ATTENTION! DO NOT USE THIS ON THE REAL COMPUTER. I AM NOT 
RESPONSIBLE FOR ANY DAMAGE CAUSED BY THE MALWARE, SO USE IT ON VIRTUAL MACHINE! OR, PLEASE USE THIS AT YOUR OWN RISK.

To get more information or source code, visit github.com/Someone8859/SystemMELTDOWN

Youtube channel: https://www.youtube.com/channel/UCW2KVYp836UYYAM-KY5mtYA
Discord Server: https://discord.gg/tDx5KA7Xc6

*****************************************************

SystemMELTDOWN Info:
Written in: C++
Language version: C++ 17 & C17
Using: Visual Studio 2019 Enterprise
MSVC v142, Clang 11.0.0

File:
Version: 1.0.3.3
Product version: 1.0.3.1
Company: FreeGenerator Inc

Orginal & Internal product: ~(Fake)~ Discord Nitro Generator.

*****************************************************

About binary executable file:

Main binary:

SystemMELTDOWN.exe is for both 32-bit and 64-bit version of Microsoft Windows. 

*****************************************************

Other binaries:

Note: Other binaries are located in the Init folder.

SystemMELTDOWN64.exe is for 64-bit version of Microsoft Windows only. We recommended using the SystemMELTDOWN64.exe for 64-bit Windows, for the best
compatibility, performance, security.

SystemMELTDOWN_cl.exe have the same code of SystemMELTDOWN.exe and SystemMELTDOWN64.exe. It's for both 32 and 64-bit, like SystemMELTDOWN.exe.
The different is SystemMELTDOWN_cl.exe has been compiled with Clang 11.0.0 in Visual Studio, not MSVC like SystemMELTDOWN.exe and SystemMELTDOWN64.exe

*****************************************************

SystemMELTDOWN.exe is an open-source (dangerous) malware. Please DO NOT USE this for illegal purpose.
(C) Copyright 2021 FreeGenerator Inc. All rights reserved.
To get more information or the source code, visit github.com/Someone8859/SystemMELTDOWN